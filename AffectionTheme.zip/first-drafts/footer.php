<!-- footer scrripts, end html tag. -->

<!-- a hook, plugin to JS-scripts bottom of document.-->
<?php wp_footer();?> 

</body>
</html>